let isDrawing = false;
let previousX, previousY;
let hue = 0;

function setup() {
  createCanvas(400, 400);
  background(0);
  colorMode(HSB, 360, 100, 100); // Set color mode to HSB 
}

function draw() {
  if (isDrawing) {
    // Change stroke color dynamically based on hue value
    stroke(hue, 100, 100);
    strokeWeight(10); // Set the line thickness
    line(previousX, previousY, mouseX, mouseY);
    
    // Increment hue value for the next stroke
    hue = (hue + 1) % 360;
  }

  previousX = mouseX;
  previousY = mouseY;
}

function mousePressed() {
  isDrawing = true;
  previousX = mouseX;
  previousY = mouseY;
}

function mouseReleased() {
  isDrawing = false;
}

function keyPressed() {
  if (key === 'h') {
    // Clear the canvas when the 'h' key is pressed
    background(0);
  }
}
